import { useState, useEffect, useRef } from "react";
import { Loader2, Download, QrCode, ExternalLink, Shield, CheckCircle, ArrowUpRight } from "lucide-react";

interface Certificate {
    _id: string;
    verificationCode: string;
    type: "online" | "practical";
    userName: string;
    courseName: string;
    trainingDate: string;
    trainingLocation?: string;
    issuedAt: string;
    score?: number;
    instructorName?: string;
}

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const BASE = window.location.origin;

const AppleIcon = () => (
    <svg viewBox="0 0 814 1000" width="11" height="13.5" fill="currentColor">
        <path d="M788.1 340.9c-5.8 4.5-108.2 62.2-108.2 190.5 0 148.4 130.3 200.9 134.2 202.2-.6 3.2-20.7 71.9-68.7 141.9-42.8 61.6-87.5 123.1-155.5 123.1s-85.5-39.5-164-39.5c-76 0-103.7 40.8-165.9 40.8s-105-57.8-155.5-127.4C46 790.5 0 663 0 541.8c0-207.5 135.4-317.5 268.4-317.5 99.8 0 183 65.8 245.8 65.8 59.2 0 152-69.1 269.1-69.1zm-135.2-84.8c-62 0-160 41.5-163.1 41.5-15.2 0-12.9-14.7-12.9-20.7 0-64.6 57.3-128.5 116.3-155.3 52.2-24 106.2-32.1 138-32.1 5.4 0 10.2.4 15.5 1.1 3.2 49.7-6.4 143.2-93.8 165.5z"/>
    </svg>
);

const GoogleIcon = () => (
    <svg viewBox="0 0 24 24" width="13" height="13">
        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
);

const QRCanvas = ({ value, size }: { value: string; size: number }) => {
    const ref = useRef<HTMLCanvasElement>(null);
    useEffect(() => {
        (async () => {
            try {
                const QR = ((await import("qrcode")) as any).default ?? await import("qrcode");
                if (ref.current) await QR.toCanvas(ref.current, value, { width: size, margin: 1.5, color: { dark: "#1e2d45", light: "#ffffff" } });
            } catch {}
        })();
    }, [value, size]);
    return <canvas ref={ref} width={size} height={size} style={{ display: "block", borderRadius: 8 }} />;
};

const Perf = () => (
    <div style={{ position: "relative", height: 28, overflow: "visible", zIndex: 1 }}>
        <div style={{ position: "absolute", left: -1, top: "50%", transform: "translateY(-50%)", width: 24, height: 24, borderRadius: "50%", background: "#f3f4f6", border: "1px solid #e5e7eb" }}/>
        <div style={{ position: "absolute", right: -1, top: "50%", transform: "translateY(-50%)", width: 24, height: 24, borderRadius: "50%", background: "#f3f4f6", border: "1px solid #e5e7eb" }}/>
        <div style={{ position: "absolute", left: 12, right: 12, top: "50%", transform: "translateY(-50%)", height: 1, backgroundImage: "repeating-linear-gradient(90deg,#e5e7eb 0px,#e5e7eb 5px,transparent 5px,transparent 11px)" }}/>
    </div>
);

const CertCard = ({ cert }: { cert: Certificate }) => {
    const [showQR, setShowQR] = useState(false);
    const [dlState, setDlState] = useState<"idle"|"loading"|"done">("idle");
    const [walletState, setWalletState] = useState<"idle"|"apple"|"google">("idle");
    const url = `${BASE}/verify/${cert.verificationCode}`;
    const fmt = (s: string) => new Date(s).toLocaleDateString("de-DE",{day:"2-digit",month:"2-digit",year:"numeric"});

    const dl = async () => {
        setDlState("loading");
        try {
            const res = await fetch(`${API}/certificates/${cert._id}/download`,{headers:{Authorization:`Bearer ${localStorage.getItem("token")}`}});
            if (!res.ok) throw new Error();
            const a = document.createElement("a"); a.href=URL.createObjectURL(await res.blob()); a.download=`Staplerschein-${cert.verificationCode}.pdf`; a.click();
            setDlState("done"); setTimeout(()=>setDlState("idle"),2500);
        } catch { alert("Download fehlgeschlagen."); setDlState("idle"); }
    };

    const wallet = async (type:"apple"|"google") => {
        setWalletState(type);
        try {
            const h={Authorization:`Bearer ${localStorage.getItem("token")}`};
            if(type==="apple"){
                const res=await fetch(`${API}/certificates/${cert._id}/wallet/apple`,{headers:h});
                if(!res.ok){const d=await res.json();alert(d.setup||d.message);return;}
                const a=document.createElement("a");a.href=URL.createObjectURL(await res.blob());a.download=`Staplerschein-${cert.verificationCode}.pkpass`;a.click();
            } else {
                const res=await fetch(`${API}/certificates/${cert._id}/wallet/google`,{headers:h});
                const d=await res.json(); if(!res.ok){alert(d.setup||d.message);return;} window.open(d.url,"_blank");
            }
        } catch{alert("Fehler.");}finally{setWalletState("idle");}
    };

    const meta=[
        {k:"AUSGESTELLT",v:fmt(cert.issuedAt)},
        {k:"AUSBILDUNG",v:fmt(cert.trainingDate)},
        ...(cert.trainingLocation?[{k:"ORT",v:cert.trainingLocation.split("–")[0].trim()}]:[]),
        ...(cert.instructorName?[{k:"AUSBILDER",v:cert.instructorName}]:[]),
    ];

    return (
        <div style={{ background:"#fff", borderRadius:20, border:"1px solid #e5e7eb", boxShadow:"0 1px 3px rgba(0,0,0,0.05),0 4px 12px rgba(0,0,0,0.04)", overflow:"hidden" }}>

            {/* TOP: dark header */}
            <div style={{ background:"linear-gradient(160deg,#1e2d45 0%,#253757 100%)", padding:"22px 24px 18px", position:"relative", overflow:"hidden" }}>
                <div style={{ position:"absolute",top:0,left:24,right:24,height:3,background:"linear-gradient(90deg,#FF6B35,#F7931E,#FF6B35)",borderRadius:"0 0 3px 3px" }}/>
                <div style={{ position:"absolute",right:-24,top:-24,width:140,height:140,borderRadius:"50%",border:"1px solid rgba(255,255,255,0.03)",pointerEvents:"none" }}/>

                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
                    <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                        <div style={{ width:26,height:26,borderRadius:7,background:"linear-gradient(135deg,#FF6B35,#F7931E)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                            <span style={{ fontSize:12,fontWeight:900,color:"#fff",fontFamily:"'Space Grotesk',sans-serif" }}>S</span>
                        </div>
                        <div>
                            <div style={{ fontSize:11,fontWeight:800,color:"#fff",letterSpacing:0.3 }}>STAPLER<span style={{ color:"#FF6B35" }}>O</span></div>
                            <div style={{ fontSize:9,color:"rgba(255,255,255,0.3)" }}>Ausbildungszentrum · Görlitz</div>
                        </div>
                    </div>
                    <div style={{ display:"flex",alignItems:"center",gap:4,padding:"3px 9px",borderRadius:100,background:"rgba(34,197,94,0.12)",border:"1px solid rgba(34,197,94,0.25)" }}>
                        <CheckCircle size={9} color="#4ade80"/>
                        <span style={{ fontSize:9,fontWeight:700,color:"#4ade80" }}>Gültig</span>
                    </div>
                </div>

                <div style={{ fontSize:8,fontWeight:700,letterSpacing:3,color:"rgba(255,107,53,0.8)",textTransform:"uppercase",marginBottom:6 }}>
                    Befähigungsnachweis · Gabelstapler
                </div>
                <div style={{ fontSize:cert.userName.length>22?20:cert.userName.length>16?24:28,fontWeight:900,color:"#fff",letterSpacing:-0.5,lineHeight:1.15,marginBottom:6 }}>
                    {cert.userName}
                </div>
                <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                    <span style={{ fontSize:11,color:"rgba(255,255,255,0.4)" }}>{cert.courseName}</span>
                    {cert.score!==undefined&&<span style={{ marginLeft:"auto",padding:"3px 9px",borderRadius:100,background:"rgba(255,107,53,0.15)",border:"1px solid rgba(255,107,53,0.3)",fontSize:10,fontWeight:800,color:"#FF6B35",flexShrink:0 }}>{cert.score}%</span>}
                </div>
            </div>

            <Perf/>

            {/* MID: meta */}
            <div style={{ padding:"16px 24px 14px" }}>
                <div style={{ display:"grid",gridTemplateColumns:`repeat(${Math.min(meta.length,4)},1fr)`,gap:1,background:"#f1f5f9",borderRadius:10,overflow:"hidden",border:"1px solid #e8edf2",marginBottom:12 }}>
                    {meta.map(({k,v},i)=>(
                        <div key={k} style={{ padding:"10px 12px",background:"#fff",borderRight:i<meta.length-1?"1px solid #f1f5f9":"none" }}>
                            <div style={{ fontSize:7.5,fontWeight:700,color:"#94a3b8",letterSpacing:1.2,marginBottom:3 }}>{k}</div>
                            <div style={{ fontSize:11.5,fontWeight:700,color:"#1e2d45",lineHeight:1.2 }}>{v}</div>
                        </div>
                    ))}
                </div>

                <div style={{ display:"flex",gap:5,marginBottom:12 }}>
                    {["DGUV Vorschrift 68","DGUV Grundsatz 308-001"].map(b=>(
                        <span key={b} style={{ padding:"3px 9px",borderRadius:100,background:"#eef2ff",border:"1px solid #c7d2fe",fontSize:8.5,fontWeight:600,color:"#4338ca" }}>{b}</span>
                    ))}
                </div>

                <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",padding:"9px 13px",borderRadius:9,background:"#fafafa",border:"1px solid #e5e7eb" }}>
                    <div>
                        <div style={{ fontSize:7.5,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:2 }}>Nr.</div>
                        <div style={{ fontFamily:"monospace",fontSize:12,fontWeight:900,color:"#1e2d45",letterSpacing:2 }}>{cert.verificationCode}</div>
                    </div>
                    <button onClick={()=>setShowQR(v=>!v)} style={{ display:"flex",alignItems:"center",gap:5,padding:"5px 11px",borderRadius:7,cursor:"pointer",fontFamily:"inherit",fontSize:10.5,fontWeight:600,transition:"all .15s",background:showQR?"#1e2d45":"transparent",color:showQR?"#fff":"#94a3b8",border:`1px solid ${showQR?"#1e2d45":"#e5e7eb"}` }}>
                        <QrCode size={10}/>QR-Code
                    </button>
                </div>

                {showQR&&(
                    <div style={{ marginTop:8,display:"grid",gridTemplateColumns:"auto 1fr",gap:14,padding:"14px",borderRadius:10,background:"#f8fafc",border:"1px solid #e2e8f0" }}>
                        <QRCanvas value={url} size={92}/>
                        <div style={{ display:"flex",flexDirection:"column",justifyContent:"space-between",gap:6 }}>
                            <div>
                                <div style={{ fontSize:11,fontWeight:700,color:"#1e2d45",marginBottom:3 }}>Echtheitsprüfung</div>
                                <div style={{ fontSize:10,color:"#64748b",lineHeight:1.55 }}>QR scannen oder Link öffnen. Keine Anmeldung erforderlich.</div>
                            </div>
                            <a href={url} target="_blank" rel="noopener noreferrer" style={{ display:"inline-flex",alignItems:"center",gap:3,fontSize:9.5,color:"#FF6B35",fontWeight:600,textDecoration:"none" }}>
                                {url.replace(/^https?:\/\//,"").substring(0,36)}… <ExternalLink size={8}/>
                            </a>
                        </div>
                    </div>
                )}
            </div>

            <Perf/>

            {/* BOTTOM: actions */}
            <div style={{ padding:"14px 24px 18px" }}>
                <button onClick={dl} disabled={dlState==="loading"} style={{ width:"100%",display:"flex",alignItems:"center",justifyContent:"center",gap:8,padding:"12px",borderRadius:11,cursor:dlState==="loading"?"default":"pointer",border:"none",fontFamily:"inherit",fontSize:12.5,fontWeight:800,letterSpacing:0.2,transition:"all .2s",background:dlState==="done"?"linear-gradient(135deg,#16a34a,#15803d)":"linear-gradient(135deg,#FF6B35 0%,#F7931E 100%)",color:"#fff",boxShadow:dlState==="loading"?"none":"0 3px 10px -2px rgba(255,107,53,0.45)" }}
                        onMouseEnter={e=>{if(dlState==="idle")(e.currentTarget as HTMLButtonElement).style.transform="translateY(-1px)";}}
                        onMouseLeave={e=>{(e.currentTarget as HTMLButtonElement).style.transform="translateY(0)";}}>
                    {dlState==="loading"?<Loader2 size={13} style={{animation:"spin .7s linear infinite"}}/>:dlState==="done"?<CheckCircle size={13}/>:<Download size={13}/>}
                    {dlState==="done"?"Heruntergeladen ✓":"Staplerschein als PDF herunterladen"}
                </button>

                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:7 }}>
                    <button onClick={()=>wallet("apple")} disabled={walletState!=="idle"} style={{ display:"flex",alignItems:"center",justifyContent:"center",gap:6,padding:"10px",borderRadius:10,cursor:walletState!=="idle"?"default":"pointer",border:"none",fontFamily:"inherit",fontSize:11,fontWeight:700,background:"#000",color:"#fff",transition:"opacity .15s",opacity:walletState!=="idle"&&walletState!=="apple"?.4:1 }}>
                        {walletState==="apple"?<Loader2 size={11} style={{animation:"spin .7s linear infinite"}}/>:<AppleIcon/>} Apple Wallet
                    </button>
                    <button onClick={()=>wallet("google")} disabled={walletState!=="idle"} style={{ display:"flex",alignItems:"center",justifyContent:"center",gap:6,padding:"10px",borderRadius:10,cursor:walletState!=="idle"?"default":"pointer",fontFamily:"inherit",fontSize:11,fontWeight:700,background:"#fff",color:"#3c4043",border:"1px solid #dadce0",boxShadow:"0 1px 4px rgba(0,0,0,0.06)",transition:"box-shadow .15s",opacity:walletState!=="idle"&&walletState!=="google"?.4:1 }}
                            onMouseEnter={e=>{(e.currentTarget as HTMLButtonElement).style.boxShadow="0 2px 10px rgba(0,0,0,0.12)";}}
                            onMouseLeave={e=>{(e.currentTarget as HTMLButtonElement).style.boxShadow="0 1px 4px rgba(0,0,0,0.06)";}}>
                        {walletState==="google"?<Loader2 size={11} style={{animation:"spin .7s linear infinite",color:"#4285F4"}}/>:<GoogleIcon/>} Google Wallet
                    </button>
                </div>

                <div style={{ textAlign:"center",marginTop:10 }}>
                    <a href={url} target="_blank" rel="noopener noreferrer" style={{ display:"inline-flex",alignItems:"center",gap:3,fontSize:10,color:"#d1d5db",textDecoration:"none",transition:"color .15s" }}
                       onMouseEnter={e=>(e.currentTarget.style.color="#64748b")} onMouseLeave={e=>(e.currentTarget.style.color="#d1d5db")}>
                        <Shield size={9}/>Öffentlich verifizieren<ArrowUpRight size={8}/>
                    </a>
                </div>
            </div>
        </div>
    );
};

const SeedBanner = ({isAdmin}:{isAdmin:boolean}) => {
    const [loading,setLoading]=useState(false);
    const [done,setDone]=useState(false);
    if(!isAdmin)return null;
    const h={Authorization:`Bearer ${localStorage.getItem("token")}`} as HeadersInit;
    return(
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 16px",borderRadius:12,marginBottom:20,background:"#fff7ed",border:"1px solid #fddcb5" }}>
            <span style={{ fontSize:12,color:"#92400e" }}><strong style={{ color:"#c2410c" }}>Admin</strong> · Demo-Zertifikat erstellen</span>
            <div style={{ display:"flex",gap:8 }}>
                <button onClick={async()=>{setLoading(true);try{await fetch(`${API}/certificates/admin/seed-demo`,{method:"POST",headers:h});setDone(true);setTimeout(()=>window.location.reload(),600);}catch{}finally{setLoading(false);}}} disabled={loading} style={{ display:"flex",alignItems:"center",gap:5,padding:"5px 12px",borderRadius:7,border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:11,fontWeight:700,background:"#FF6B35",color:"#fff",opacity:loading?.6:1 }}>
                    {loading?<Loader2 size={10} style={{animation:"spin .7s linear infinite"}}/>:null}{done?"✓ Erstellt!":"Demo erstellen"}
                </button>
                <button onClick={async()=>{if(!confirm("Demo löschen?"))return;await fetch(`${API}/certificates/admin/seed-demo`,{method:"DELETE",headers:h});window.location.reload();}} style={{ background:"none",border:"none",cursor:"pointer",fontSize:11,color:"#92400e",fontFamily:"inherit" }}>Löschen</button>
            </div>
        </div>
    );
};

const CertificateSection = ({isAdmin=false}:{isAdmin?:boolean}) => {
    const [certs,setCerts]=useState<Certificate[]>([]);
    const [loading,setLoading]=useState(true);
    useEffect(()=>{
        (async()=>{
            try{const res=await fetch(`${API}/certificates/my`,{headers:{Authorization:`Bearer ${localStorage.getItem("token")}`}});if(res.ok)setCerts(await res.json());}
            catch{}finally{setLoading(false);}
        })();
    },[]);

    if(loading)return(
        <div style={{ display:"flex",justifyContent:"center",padding:"80px 0" }}>
            <div style={{ width:28,height:28,borderRadius:"50%",border:"2.5px solid #FF6B35",borderTopColor:"transparent",animation:"spin .7s linear infinite" }}/>
        </div>
    );

    return(
        <div>
            <div style={{ marginBottom:24 }}>
                <h2 style={{ fontSize:22,fontWeight:900,color:"#1e2d45",margin:0,letterSpacing:-0.3 }}>Meine Zertifikate</h2>
                <p style={{ fontSize:13,color:"#94a3b8",margin:"4px 0 0" }}>Staplerschein · DGUV Vorschrift 68 · Grundsatz 308-001</p>
            </div>
            <SeedBanner isAdmin={isAdmin}/>
            {certs.length===0?(
                <div style={{ padding:"56px 32px",borderRadius:20,textAlign:"center",background:"#f8fafc",border:"1.5px dashed #e2e8f0" }}>
                    <div style={{ width:48,height:48,borderRadius:13,margin:"0 auto 14px",background:"linear-gradient(135deg,#1e2d45,#253757)",display:"flex",alignItems:"center",justifyContent:"center" }}>
                        <span style={{ fontSize:20,fontWeight:900,color:"#FF6B35" }}>S</span>
                    </div>
                    <div style={{ fontSize:14,fontWeight:800,color:"#1e2d45",marginBottom:6 }}>Noch kein Zertifikat</div>
                    <div style={{ fontSize:12.5,color:"#64748b",lineHeight:1.7,maxWidth:250,margin:"0 auto" }}>Nach dem Abschluss Ihrer Ausbildung erscheint Ihr Staplerschein hier.</div>
                </div>
            ):(
                <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))",gap:20,alignItems:"start" }}>
                    {certs.map(c=><CertCard key={c._id} cert={c}/>)}
                </div>
            )}
        </div>
    );
};

export default CertificateSection;