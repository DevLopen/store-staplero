import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { CheckCircle, XCircle, AlertCircle, Loader2, Award, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

interface VerifyResult {
    valid: boolean;
    revoked?: boolean;
    type?: "online" | "practical";
    userName?: string;
    courseName?: string;
    trainingDate?: string;
    trainingLocation?: string;
    issuedAt?: string;
    verificationCode?: string;
    score?: number;
    message?: string;
}

const VerifyCertificate = () => {
    const { code } = useParams<{ code: string }>();
    const [result, setResult] = useState<VerifyResult | null>(null);
    const [loading, setLoading] = useState(true);
    const [manualCode, setManualCode] = useState("");

    useEffect(() => {
        if (code) {
            verify(code);
        } else {
            setLoading(false);
        }
    }, [code]);

    const verify = async (verifyCode: string) => {
        setLoading(true);
        try {
            const res = await fetch(`${API_URL}/certificates/verify/${verifyCode.trim().toUpperCase()}`);
            const data = await res.json();
            setResult(data);
        } catch {
            setResult({ valid: false, message: "Verbindungsfehler. Bitte erneut versuchen." });
        } finally {
            setLoading(false);
        }
    };

    const handleManualVerify = (e: React.FormEvent) => {
        e.preventDefault();
        if (manualCode.trim()) verify(manualCode);
    };

    const formatDate = (dateStr: string) =>
        new Date(dateStr).toLocaleDateString("de-DE", {
            year: "numeric", month: "long", day: "numeric",
        });

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
            <div className="w-full max-w-lg">
                {/* Logo */}
                <div className="text-center mb-8">
                    <Link to="/" className="inline-flex items-center gap-2">
                        <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
                            <Award className="w-5 h-5 text-amber-400" />
                        </div>
                        <span className="text-2xl font-black text-white">
              STAPLER<span className="text-amber-400">O</span>
            </span>
                    </Link>
                    <p className="text-slate-400 text-sm mt-2">Zertifikatsverifizierung</p>
                </div>

                {/* Main card */}
                <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-8">
                    <h1 className="text-xl font-bold text-white mb-2 text-center">
                        Echtheitsprüfung
                    </h1>
                    <p className="text-slate-400 text-sm text-center mb-6">
                        Diese Seite dient ausschließlich der Echtheitsprüfung von STAPLERO-Zertifikaten
                        gemäß DGUV Vorschrift 68.
                    </p>

                    {/* Manual input */}
                    {!loading && (
                        <form onSubmit={handleManualVerify} className="mb-6">
                            <label className="block text-slate-400 text-xs uppercase tracking-wider mb-2">
                                Zertifikat-Nummer eingeben
                            </label>
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    value={manualCode}
                                    onChange={(e) => setManualCode(e.target.value.toUpperCase())}
                                    placeholder="z.B. AB1234CD5678"
                                    maxLength={12}
                                    className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 font-mono tracking-wider text-sm focus:outline-none focus:border-amber-500/50 uppercase"
                                />
                                <Button
                                    type="submit"
                                    className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold px-6"
                                >
                                    Prüfen
                                </Button>
                            </div>
                        </form>
                    )}

                    {/* Result */}
                    {loading && (
                        <div className="flex items-center justify-center py-12">
                            <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
                        </div>
                    )}

                    {!loading && result && (
                        <div className={`rounded-xl overflow-hidden border ${
                            result.valid
                                ? "border-green-500/30"
                                : result.revoked
                                    ? "border-orange-500/30"
                                    : "border-red-500/30"
                        }`}>
                            {/* Status header */}
                            <div className={`px-6 py-4 flex items-center gap-3 ${
                                result.valid
                                    ? "bg-green-500/10"
                                    : result.revoked
                                        ? "bg-orange-500/10"
                                        : "bg-red-500/10"
                            }`}>
                                {result.valid ? (
                                    <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0" />
                                ) : result.revoked ? (
                                    <AlertCircle className="w-6 h-6 text-orange-400 flex-shrink-0" />
                                ) : (
                                    <XCircle className="w-6 h-6 text-red-400 flex-shrink-0" />
                                )}
                                <div>
                                    <p className={`font-bold text-sm ${
                                        result.valid ? "text-green-300" : result.revoked ? "text-orange-300" : "text-red-300"
                                    }`}>
                                        {result.valid
                                            ? "✓ Zertifikat gültig und echt"
                                            : result.revoked
                                                ? "⚠ Zertifikat wurde widerrufen"
                                                : "✗ Zertifikat nicht gefunden"}
                                    </p>
                                    {!result.valid && result.message && (
                                        <p className="text-slate-400 text-xs mt-0.5">{result.message}</p>
                                    )}
                                </div>
                            </div>

                            {/* Certificate details */}
                            {result.valid && result.userName && (
                                <div className="bg-slate-800/80 p-6 space-y-4">
                                    <div className="text-center pb-4 border-b border-slate-700/50">
                                        <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">Inhaber</p>
                                        <p className="text-white font-bold text-xl">{result.userName}</p>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">Kurs</p>
                                            <p className="text-slate-200 text-sm font-medium">{result.courseName}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">Typ</p>
                                            <p className="text-slate-200 text-sm font-medium capitalize">
                                                {result.type === "practical" ? "Praxiskurs" : "Online-Kurs"}
                                            </p>
                                        </div>
                                        {result.trainingDate && (
                                            <div>
                                                <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">
                                                    Ausbildungsdatum
                                                </p>
                                                <p className="text-slate-200 text-sm font-medium">
                                                    {formatDate(result.trainingDate)}
                                                </p>
                                            </div>
                                        )}
                                        {result.issuedAt && (
                                            <div>
                                                <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">
                                                    Ausgestellt am
                                                </p>
                                                <p className="text-slate-200 text-sm font-medium">
                                                    {formatDate(result.issuedAt)}
                                                </p>
                                            </div>
                                        )}
                                        {result.trainingLocation && (
                                            <div className="col-span-2">
                                                <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">
                                                    Ausbildungsort
                                                </p>
                                                <p className="text-slate-200 text-sm font-medium">{result.trainingLocation}</p>
                                            </div>
                                        )}
                                        {result.score !== undefined && (
                                            <div>
                                                <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">
                                                    Prüfungsergebnis
                                                </p>
                                                <p className="text-slate-200 text-sm font-medium">{result.score}%</p>
                                            </div>
                                        )}
                                        {result.verificationCode && (
                                            <div>
                                                <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1">
                                                    Zertifikat-Nr.
                                                </p>
                                                <p className="font-mono text-amber-400 text-sm font-bold tracking-widest">
                                                    {result.verificationCode}
                                                </p>
                                            </div>
                                        )}
                                    </div>

                                    <div className="pt-3 border-t border-slate-700/50">
                                        <p className="text-slate-500 text-[10px] text-center">
                                            DGUV Vorschrift 68 · DGUV Grundsatz 308-001 · Ausgestellt von STAPLERO
                                        </p>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* Footer note */}
                <p className="text-slate-600 text-xs text-center mt-6">
                    STAPLERO Ausbildungszentrum · Jakobstr. 13, 02826 Görlitz ·{" "}
                    <Link to="/" className="hover:text-slate-400 transition-colors">
                        staplero.com
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default VerifyCertificate;